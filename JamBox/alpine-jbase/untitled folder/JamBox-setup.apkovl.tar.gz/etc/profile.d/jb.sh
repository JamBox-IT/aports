#!/bin/sh
export PATH=$PATH:/usr/bin/jb
