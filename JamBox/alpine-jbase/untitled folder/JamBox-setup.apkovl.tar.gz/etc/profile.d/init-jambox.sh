#!/bin/sh
#########
#
# Copyright Corey DeLasaux <cordelster@gmail.com> (2017)
#


PREFIX=

. "$PREFIX/etc/jambox/jambox.conf"



if [ -f $PEMFILE ]; then
 return
fi
#echo "Enter root password:"
#sudo /sbin/init-jambox && passwd
/sbin/init-jambox && passwd

